Tannon Carro
Natneal Haile
Mohamed Elgendy
Jaspreet Bassi

Mengistu CS-211-002

******This program was created specifically for Ron Knapp, so it follows his specifications.******

General Rules-

	*In order for the program to work correctly, the folder containing this READ_ME file, as well as the project,
		txtFiles, and printFiles folders will have to be moved to the desktop of your computer.
	*This means the whole folder (titled "PopPop") will have to be moved to the desktop.
	*Do NOT move any files or folders within the folder containing the whole project to anywhere
		outside the folder.
	*You may create a shortcut for the .jar file that runs the program to place on your desktop
	*Within the txtFiles and printFiles folders, there are txt files titled "-". The user can choose to keep or 
		delete these files. The file in the printFiles folder will never be seen by the user, but the one in txtFiles 
		will. In the Load Class section, it will appear in the slection box. It is up to the user whether they want to keep it.

Specific Rules-

	*Setting a New Class:
		-Date must be in said format, otherwise will show an error message prompting the user to change it.
		-Number of students must be a whole number; it cannot be anything other than a number and must be whole, 
			not including a decimal (1, 2, 3, etc.). If it is not, an error message will prompt 
			the user to change it.
		-Number of meetings follows the same rule as number of students. Only whole numbers.
		-Name can be any combination of letters and numbers AS LONG AS the file does not already exist.
			If it does, an error message will prompt the user to change it.
		-File is saved as (name)_(date), so a new file will be created as long as the user does not have the same 
			combination of name and date. It can be the same name but different date and it will still save, and vice versa.

	*Loading an Existing Class:
		-If the user has not created their first class, then clicking "Load" will give an error message prompting 
			the user to create a class first.
		-If the file the user is trying to load is misplaced (moved out of the txtFiles folder), it will not appear 
			in the selection box.
		
	*Editing a Newly Created or a Loaded Class
		-The user must enter only whole numbers for all cells of the table except for those in the first column (for name).
			If the user does not enter whole numbers, an error message will prompt them to change it.
		-The values in  "Participation average", "Assignment Average", "Quiz Average" "Participation total", "Assignment total", "Quiz total",and "Overall"
			will be changed once the user clicks save so it is redudent to enter any values in these columns.
		-The user MUST click save after finished. In a New Class, the file is not created and cannot be loaded. In a Loaded Class, the file will revert back 
			to the values that were in the table BEFORE any editing was made in the session.











